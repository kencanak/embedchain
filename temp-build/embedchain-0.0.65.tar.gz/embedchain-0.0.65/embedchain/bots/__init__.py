from embedchain.bots.poe import PoeBot  # noqa: F401
from embedchain.bots.whatsapp import WhatsAppBot  # noqa: F401

# TODO: fix discord import
# from embedchain.bots.discord import DiscordBot
